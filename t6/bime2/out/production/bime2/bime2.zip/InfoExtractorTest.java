import static org.junit.Assert.*;
import org.junit.*;

public class InfoExtractorTest {

    @Before
    public void prepare(){

    }

    @Test
    public void getPaymentsPerHour() {
    }

    @Test
    public void getLaziest() {
    }

    @Test
    public void sortOnSuccess() {
    }

    @Test
    public void getRichestSorted() {
    }
}