public class DataInputOverflowException extends RuntimeException {

    public DataInputOverflowException() {
    }

    public DataInputOverflowException(String message) {
        super(message);
    }

}