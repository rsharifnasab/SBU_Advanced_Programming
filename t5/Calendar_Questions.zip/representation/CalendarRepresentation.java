package representation;

import calendar.CustomCalendar;

public interface CalendarRepresentation {
    String getRepresentation(CustomCalendar calendar);
}
