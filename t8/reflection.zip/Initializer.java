import annotation.Instantiate;
import annotation.Connect;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.util.*;

public class Initializer {
	
	public static Collection<Object> init(List<String> classNames) {
		// TODO
	}
	
}
