public class InitializeException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public InitializeException() {
		super();
	}

}
