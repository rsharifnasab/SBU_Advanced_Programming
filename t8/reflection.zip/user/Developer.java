package user;

import annotation.Instantiate;

@Instantiate
public class Developer {

}
