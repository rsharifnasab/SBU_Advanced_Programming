package user;

public class Employee {

}
