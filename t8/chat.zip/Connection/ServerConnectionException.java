package Connection;

public class ServerConnectionException extends RuntimeException
{
    public ServerConnectionException() {
        super("Server Connection Exception");
    }
}
