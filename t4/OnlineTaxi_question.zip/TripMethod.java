
public abstract class TripMethod {
	public abstract int calcPrice(TripParam params);

}
