
public class TripHandler {

	public int calcPrice(String type, TripParam params) {
		//your implementation

	}

}
