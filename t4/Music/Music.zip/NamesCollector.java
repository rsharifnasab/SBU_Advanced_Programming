public class NamesCollector extends DataCollector {
    public Object get(Music music){
      return music.getName();
    }
}
