public class AlbumsCollector extends DataCollector {
    public Object get(Music music){
      return music.getAlbum();
    }
}
